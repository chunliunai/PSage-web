# vue-ai-test 前端项目上下文

## 项目基础信息

| 项目 | 说明 |
|------|------|
| 项目路径 | `/Users/10298249/Desktop/vue-ai-test/vue-ai-test` |
| 框架 | Vue 3 + Vite 7 |
| 包管理 | npm |
| 开发端口 | 5173 |
| 对应后端 | ai-test1（localhost:9090） |

## 启动命令

```bash
cd /Users/10298249/Desktop/vue-ai-test/vue-ai-test
npm run dev
```

## 目录结构

```
src/
├── main.js                # 入口，注册 router
├── App.vue                # 根组件（导航栏 + router-view）
├── components/
│   └── AIAnalyzer.vue     # AI 分析核心组件
├── views/
│   ├── LoginView.vue      # 登录页
│   ├── RegisterView.vue   # 注册页
│   ├── HistoryView.vue    # 历史记录页
│   └── AdminView.vue      # 管理后台（仅 ADMIN）
├── router/
│   └── index.js           # 路由 + 导航守卫（登录守卫 + 角色守卫）
└── utils/
    ├── auth.js            # token/用户信息存取（封装 localStorage）
    └── request.js         # axios 封装（自动带 token，401 跳登录页）
```

## 已完成功能

- [x] AI 分析页（AIAnalyzer.vue）
- [x] 登录 / 注册页（JWT token 存 localStorage）
- [x] 路由系统 + 导航守卫（未登录跳登录页，非 ADMIN 跳首页）
- [x] axios 封装（自动带 Authorization 头，401 自动跳登录页）
- [x] 历史记录页（分页/搜索/详情弹窗/删除/清空）
- [x] 管理后台（用户列表/改角色/删用户/全局历史，仅 ADMIN 可见）
- [x] 导航栏（登录状态/用户名/ADMIN 徽章/退出登录）

## 路由一览

| 路径 | 组件 | 权限 |
|------|------|------|
| `/login` | LoginView | 无需登录 |
| `/register` | RegisterView | 无需登录 |
| `/` | AIAnalyzer | 需登录 |
| `/history` | HistoryView | 需登录 |
| `/admin` | AdminView | 需登录 + ADMIN 角色 |

## Vite 代理配置

`/api/*` → `http://localhost:9090/api/*`（解决跨域，仅开发环境生效）

## 协作约定

- 修改代码前告知改哪个文件、改哪里、为什么，等确认再动手
- 帮助文档路径：`/Users/10298249/Desktop/vue-ai-test/dev_help.md`
