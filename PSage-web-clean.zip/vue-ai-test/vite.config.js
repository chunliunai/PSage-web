import { fileURLToPath, URL } from 'node:url'
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
// https://vite.dev/config/
export default defineConfig({
  plugins: [
    vue(),
  ],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url))
    },
  },
  server: {
    host: true,   // 监听所有网络接口，局域网内可访问
    proxy: {
      // 当请求路径以 /api 开头时，代理到后端地址
      '/api': {
        target: 'http://localhost:9090', // 你的 Spring Boot 后端地址
        changeOrigin: true,               // 支持跨域
      }
    }
  }
})