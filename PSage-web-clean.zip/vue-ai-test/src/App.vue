<template>
  <div id="app">
    <!-- 导航栏：只在已登录时显示 -->
    <nav v-if="isLoggedIn" class="navbar">
      <div class="nav-left">
        <span class="nav-brand" @click="$router.push('/')">🔒 AI 安全分析</span>
        <router-link to="/" class="nav-link">分析</router-link>
        <router-link to="/history" class="nav-link">历史记录</router-link>
        <!-- 仅 ADMIN 显示管理后台入口 -->
        <router-link v-if="isAdmin" to="/admin" class="nav-link nav-admin">管理后台</router-link>
      </div>
      <div class="nav-right">
        <span class="nav-user">{{ currentUser?.username }}</span>
        <span v-if="isAdmin" class="admin-badge">ADMIN</span>
        <button class="logout-btn" @click="handleLogout">退出登录</button>
      </div>
    </nav>

    <!-- 路由出口 -->
    <router-view />
  </div>
</template>

<script>
import { isLoggedIn, getUser, logout } from './utils/auth'

export default {
  name: 'App',
  data() {
    return {
      isLoggedIn: isLoggedIn(),
      currentUser: getUser(),
    }
  },
  computed: {
    isAdmin() {
      return this.currentUser?.role === 'ADMIN'
    },
  },
  watch: {
    $route() {
      this.isLoggedIn = isLoggedIn()
      this.currentUser = getUser()
    },
  },
  methods: {
    handleLogout() {
      logout()
      this.isLoggedIn = false
      this.currentUser = null
      this.$router.push('/login')
    },
  },
}
</script>

<style>
body {
  margin: 0;
  background-color: #f5f5f5;
}

.navbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 24px;
  height: 52px;
  background: #fff;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.1);
}
.nav-left {
  display: flex;
  align-items: center;
  gap: 20px;
}
.nav-brand {
  font-weight: bold;
  font-size: 16px;
  cursor: pointer;
}
.nav-link {
  font-size: 14px;
  color: #555;
  text-decoration: none;
  padding: 4px 0;
  border-bottom: 2px solid transparent;
}
.nav-link:hover { color: #4caf50; }
.nav-link.router-link-active {
  color: #4caf50;
  border-bottom-color: #4caf50;
  font-weight: bold;
}
.nav-admin { color: #e65100 !important; }
.nav-admin.router-link-active { border-bottom-color: #e65100 !important; }
.nav-right {
  display: flex;
  align-items: center;
  gap: 12px;
}
.nav-user { font-size: 14px; color: #555; }
.admin-badge {
  background: #fff3e0;
  color: #e65100;
  font-size: 11px;
  font-weight: bold;
  padding: 2px 6px;
  border-radius: 8px;
}
.logout-btn {
  padding: 6px 14px;
  background: #f44336;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 13px;
}
.logout-btn:hover { background: #d32f2f; }
</style>
