/**
 * router/index.js - 路由配置
 *
 * 作用：
 *   1. 定义 URL 路径和组件的对应关系
 *   2. 导航守卫：未登录跳登录页，非管理员访问 /admin 跳首页
 */

import { createRouter, createWebHistory } from 'vue-router'
import { isLoggedIn, getUser } from '../utils/auth'
import LoginView from '../views/LoginView.vue'
import RegisterView from '../views/RegisterView.vue'
import AIAnalyzer from '../components/AIAnalyzer.vue'
import HistoryView from '../views/HistoryView.vue'
import AdminView from '../views/AdminView.vue'

const routes = [
  {
    path: '/login',
    component: LoginView,
    meta: { requiresAuth: false },
  },
  {
    path: '/register',
    component: RegisterView,
    meta: { requiresAuth: false },
  },
  {
    path: '/',
    component: AIAnalyzer,
    meta: { requiresAuth: true },
  },
  {
    path: '/history',
    component: HistoryView,
    meta: { requiresAuth: true },
  },
  {
    path: '/admin',
    component: AdminView,
    meta: { requiresAuth: true, requiresAdmin: true },  // 额外要求管理员角色
  },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

// ===== 导航守卫 =====
router.beforeEach((to, from, next) => {
  // 1. 需要登录但未登录 → 跳登录页
  if (to.meta.requiresAuth && !isLoggedIn()) {
    next('/login')
    return
  }

  // 2. 需要管理员但当前角色不是 ADMIN → 跳首页
  if (to.meta.requiresAdmin && getUser()?.role !== 'ADMIN') {
    next('/')
    return
  }

  // 3. 已登录还访问登录/注册页 → 跳首页
  if ((to.path === '/login' || to.path === '/register') && isLoggedIn()) {
    next('/')
    return
  }

  next()
})

export default router
