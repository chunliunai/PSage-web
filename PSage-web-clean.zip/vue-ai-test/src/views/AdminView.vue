<template>
  <div class="admin-container">
    <h2>管理后台</h2>

    <!-- Tab 切换 -->
    <div class="tabs">
      <button :class="['tab', activeTab === 'users' ? 'active' : '']" @click="switchTab('users')">用户管理</button>
      <button :class="['tab', activeTab === 'history' ? 'active' : '']" @click="switchTab('history')">全局历史</button>
    </div>

    <!-- ===== 用户管理 Tab ===== -->
    <div v-if="activeTab === 'users'">
      <div v-if="usersLoading" class="tip">加载中...</div>
      <div v-else>
        <table class="data-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>用户名</th>
              <th>角色</th>
              <th>注册时间</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="user in userList" :key="user.id">
              <td>{{ user.id }}</td>
              <td>{{ user.username }}</td>
              <td>
                <span :class="['role-tag', user.role === 'ADMIN' ? 'role-admin' : 'role-user']">
                  {{ user.role }}
                </span>
              </td>
              <td>{{ formatTime(user.createdAt) }}</td>
              <td class="actions">
                <!-- 修改角色 -->
                <button
                  @click="toggleRole(user)"
                  class="btn-sm btn-warn"
                >
                  改为 {{ user.role === 'ADMIN' ? 'USER' : 'ADMIN' }}
                </button>
                <!-- 删除（不能删自己） -->
                <button
                  @click="deleteUser(user)"
                  class="btn-sm btn-danger"
                  :disabled="user.id === currentUserId"
                >
                  删除
                </button>
              </td>
            </tr>
          </tbody>
        </table>

        <!-- 用户分页 -->
        <div class="pagination">
          <button @click="changeUserPage(userPage - 1)" :disabled="userPage === 1">上一页</button>
          <span>第 {{ userPage }} / {{ userTotalPages }} 页，共 {{ userTotal }} 人</span>
          <button @click="changeUserPage(userPage + 1)" :disabled="userPage === userTotalPages">下一页</button>
        </div>
      </div>
    </div>

    <!-- ===== 全局历史 Tab ===== -->
    <div v-if="activeTab === 'history'">
      <div v-if="historyLoading" class="tip">加载中...</div>
      <div v-else-if="historyList.length === 0" class="tip">暂无历史记录</div>
      <div v-else>
        <div v-for="item in historyList" :key="item.id" class="history-card">
          <div class="card-header">
            <span class="card-time">ID:{{ item.userId }} — {{ formatTime(item.createdAt) }}</span>
          </div>
          <div class="card-section">
            <div class="label">请求包</div>
            <pre class="preview">{{ truncate(item.request, 150) }}</pre>
          </div>
          <div class="card-section">
            <div class="label">分析结果</div>
            <pre class="preview result">{{ truncate(formatResult(item.response), 150) }}</pre>
          </div>
        </div>

        <!-- 历史分页 -->
        <div class="pagination">
          <button @click="changeHistoryPage(historyPage - 1)" :disabled="historyPage === 1">上一页</button>
          <span>第 {{ historyPage }} / {{ historyTotalPages }} 页，共 {{ historyTotal }} 条</span>
          <button @click="changeHistoryPage(historyPage + 1)" :disabled="historyPage === historyTotalPages">下一页</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import request from '../utils/request'
import { getUser } from '../utils/auth'

export default {
  data() {
    return {
      activeTab: 'users',
      currentUserId: getUser()?.id,

      // 用户管理
      userList: [],
      usersLoading: false,
      userPage: 1,
      userTotal: 0,
      userTotalPages: 1,

      // 全局历史
      historyList: [],
      historyLoading: false,
      historyPage: 1,
      historyTotal: 0,
      historyTotalPages: 1,
    }
  },
  mounted() {
    this.loadUsers()
  },
  methods: {
    switchTab(tab) {
      this.activeTab = tab
      if (tab === 'users') this.loadUsers()
      if (tab === 'history') this.loadHistory()
    },

    // 加载用户列表
    async loadUsers() {
      this.usersLoading = true
      try {
        const res = await request.get('/admin/users', {
          params: { page: this.userPage, size: 10 },
        })
        if (res.data.code === 200) {
          const page = res.data.data
          this.userList = page.content
          this.userTotal = page.totalElements
          this.userTotalPages = page.totalPages || 1
        }
      } catch (err) {
        console.error('加载用户失败', err)
      } finally {
        this.usersLoading = false
      }
    },

    changeUserPage(page) {
      if (page < 1 || page > this.userTotalPages) return
      this.userPage = page
      this.loadUsers()
    },

    // 切换用户角色
    async toggleRole(user) {
      const newRole = user.role === 'ADMIN' ? 'USER' : 'ADMIN'
      if (!confirm(`确认将【${user.username}】的角色改为 ${newRole}？`)) return
      try {
        const res = await request.post(`/admin/updateRole?userId=${user.id}&role=${newRole}`)
        if (res.data.code === 200) this.loadUsers()
      } catch (err) {
        console.error('修改角色失败', err)
      }
    },

    // 删除用户
    async deleteUser(user) {
      if (!confirm(`确认删除用户【${user.username}】？将同时删除其所有历史记录，不可恢复！`)) return
      try {
        const res = await request.post(`/admin/deleteUser?userId=${user.id}`)
        if (res.data.code === 200) this.loadUsers()
      } catch (err) {
        console.error('删除用户失败', err)
      }
    },

    // 加载全局历史
    async loadHistory() {
      this.historyLoading = true
      try {
        const res = await request.get('/admin/history/all', {
          params: { page: this.historyPage, size: 10 },
        })
        if (res.data.code === 200) {
          const page = res.data.data
          this.historyList = page.content
          this.historyTotal = page.totalElements
          this.historyTotalPages = page.totalPages || 1
        }
      } catch (err) {
        console.error('加载历史失败', err)
      } finally {
        this.historyLoading = false
      }
    },

    changeHistoryPage(page) {
      if (page < 1 || page > this.historyTotalPages) return
      this.historyPage = page
      this.loadHistory()
    },

    formatTime(dt) {
      if (!dt) return ''
      return dt.replace('T', ' ').substring(0, 19)
    },

    truncate(str, len) {
      if (!str) return ''
      return str.length > len ? str.substring(0, len) + '...' : str
    },

    formatResult(str) {
      try {
        return JSON.stringify(JSON.parse(str), null, 2)
      } catch {
        return str
      }
    },
  },
}
</script>

<style scoped>
.admin-container {
  max-width: 1000px;
  margin: 30px auto;
  padding: 0 20px;
}
.admin-container h2 { margin-bottom: 20px; }
.tabs {
  display: flex;
  gap: 0;
  margin-bottom: 24px;
  border-bottom: 2px solid #e0e0e0;
}
.tab {
  padding: 10px 24px;
  background: none;
  border: none;
  cursor: pointer;
  font-size: 15px;
  color: #666;
  border-bottom: 2px solid transparent;
  margin-bottom: -2px;
}
.tab.active { color: #4caf50; border-bottom-color: #4caf50; font-weight: bold; }
.data-table {
  width: 100%;
  border-collapse: collapse;
  background: #fff;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 1px 4px rgba(0,0,0,0.08);
}
.data-table th {
  background: #f5f5f5;
  padding: 12px 16px;
  text-align: left;
  font-size: 14px;
  color: #555;
}
.data-table td {
  padding: 12px 16px;
  border-top: 1px solid #f0f0f0;
  font-size: 14px;
}
.role-tag {
  padding: 2px 8px;
  border-radius: 10px;
  font-size: 12px;
  font-weight: bold;
}
.role-admin { background: #fff3e0; color: #e65100; }
.role-user  { background: #e8f5e9; color: #2e7d32; }
.actions { display: flex; gap: 8px; }
.btn-sm {
  padding: 4px 10px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 13px;
}
.btn-warn   { background: #ff9800; color: white; }
.btn-danger { background: #f44336; color: white; }
.btn-sm:disabled { background: #e0e0e0; color: #9e9e9e; cursor: not-allowed; }
.tip { text-align: center; color: #999; margin: 60px 0; }
.pagination {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 16px;
  margin: 24px 0;
  font-size: 14px;
  color: #555;
}
.pagination button {
  padding: 6px 14px;
  border: 1px solid #ddd;
  border-radius: 4px;
  cursor: pointer;
  background: #fff;
}
.pagination button:disabled { color: #ccc; cursor: not-allowed; }

/* 历史卡片（复用） */
.history-card {
  background: #fff;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  padding: 16px;
  margin-bottom: 16px;
}
.card-header { margin-bottom: 10px; }
.card-time { font-size: 13px; color: #888; }
.card-section { margin-bottom: 8px; }
.label { font-size: 12px; color: #999; margin-bottom: 4px; }
.preview {
  background: #f5f5f5;
  border-radius: 4px;
  padding: 8px;
  font-size: 12px;
  white-space: pre-wrap;
  word-break: break-all;
  margin: 0;
  max-height: 80px;
  overflow: hidden;
}
.preview.result { border-left: 3px solid #4caf50; }
</style>
