<template>
  <div class="history-container">
    <div class="page-header">
      <h2>分析历史</h2>

      <!-- 搜索栏 + 清空按钮 -->
      <div class="toolbar">
        <input
          v-model="keyword"
          @keyup.enter="handleSearch"
          placeholder="搜索请求包或分析结果..."
          class="search-input"
        />
        <button @click="handleSearch" class="btn-search">搜索</button>
        <button @click="resetSearch" class="btn-reset" v-if="isSearching">重置</button>
        <button @click="confirmClearAll" class="btn-danger">清空全部</button>
      </div>
    </div>

    <!-- 加载中 -->
    <div v-if="loading" class="tip">加载中...</div>

    <!-- 空状态 -->
    <div v-else-if="list.length === 0" class="tip">暂无历史记录</div>

    <!-- 历史列表 -->
    <div v-else>
      <div v-for="item in list" :key="item.id" class="history-card">
        <div class="card-header">
          <span class="card-time">{{ formatTime(item.createdAt) }}</span>
          <button @click="deleteItem(item.id)" class="btn-delete">删除</button>
        </div>

        <!-- 请求包预览（截断显示） -->
        <div class="card-section">
          <div class="label">请求包</div>
          <pre class="preview">{{ truncate(item.request, 150) }}</pre>
        </div>

        <!-- AI 结果预览 -->
        <div class="card-section">
          <div class="label">分析结果</div>
          <pre class="preview result">{{ formatResult(item.response) }}</pre>
        </div>

        <!-- 查看详情按钮 -->
        <button @click="openDetail(item)" class="btn-detail">查看完整内容</button>
      </div>

      <!-- 分页 -->
      <div class="pagination">
        <button @click="changePage(currentPage - 1)" :disabled="currentPage === 1">上一页</button>
        <span>第 {{ currentPage }} / {{ totalPages }} 页，共 {{ total }} 条</span>
        <button @click="changePage(currentPage + 1)" :disabled="currentPage === totalPages">下一页</button>
      </div>
    </div>

    <!-- 详情弹窗 -->
    <div v-if="detailItem" class="modal-mask" @click.self="detailItem = null">
      <div class="modal">
        <div class="modal-header">
          <span>详情 — {{ formatTime(detailItem.createdAt) }}</span>
          <button @click="detailItem = null" class="modal-close">✕</button>
        </div>
        <div class="modal-body">
          <div class="label">请求包</div>
          <pre class="full-content">{{ detailItem.request }}</pre>
          <div class="label" style="margin-top:16px">分析结果</div>
          <pre class="full-content result">{{ formatResult(detailItem.response) }}</pre>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import request from '../utils/request'

export default {
  data() {
    return {
      list: [],
      loading: false,
      currentPage: 1,
      pageSize: 10,
      total: 0,
      totalPages: 1,
      keyword: '',
      isSearching: false,
      detailItem: null,
    }
  },
  mounted() {
    this.loadList()
  },
  methods: {
    // 加载列表（普通分页或搜索分页）
    async loadList() {
      this.loading = true
      try {
        let res
        if (this.isSearching && this.keyword.trim()) {
          res = await request.get('/history/search', {
            params: { keyword: this.keyword, page: this.currentPage, size: this.pageSize },
          })
        } else {
          res = await request.get('/history/list', {
            params: { page: this.currentPage, size: this.pageSize },
          })
        }
        if (res.data.code === 200) {
          const page = res.data.data
          this.list = page.content
          this.total = page.totalElements
          this.totalPages = page.totalPages || 1
        }
      } catch (err) {
        console.error('加载失败', err)
      } finally {
        this.loading = false
      }
    },

    // 搜索
    handleSearch() {
      if (!this.keyword.trim()) return
      this.isSearching = true
      this.currentPage = 1
      this.loadList()
    },

    // 重置搜索
    resetSearch() {
      this.keyword = ''
      this.isSearching = false
      this.currentPage = 1
      this.loadList()
    },

    // 翻页
    changePage(page) {
      if (page < 1 || page > this.totalPages) return
      this.currentPage = page
      this.loadList()
    },

    // 删除单条
    async deleteItem(id) {
      if (!confirm('确认删除这条记录？')) return
      try {
        const res = await request.post(`/history/delete?historyId=${id}`)
        if (res.data.code === 200) this.loadList()
      } catch (err) {
        console.error('删除失败', err)
      }
    },

    // 清空全部
    async confirmClearAll() {
      if (!confirm('确认清空所有历史记录？此操作不可恢复！')) return
      try {
        const res = await request.post('/history/clear')
        if (res.data.code === 200) {
          this.currentPage = 1
          this.loadList()
        }
      } catch (err) {
        console.error('清空失败', err)
      }
    },

    // 打开详情弹窗
    openDetail(item) {
      this.detailItem = item
    },

    // 格式化时间
    formatTime(dt) {
      if (!dt) return ''
      return dt.replace('T', ' ').substring(0, 19)
    },

    // 截断文本
    truncate(str, len) {
      if (!str) return ''
      return str.length > len ? str.substring(0, len) + '...' : str
    },

    // 格式化 AI 结果（JSON 美化显示）
    formatResult(str) {
      try {
        return JSON.stringify(JSON.parse(str), null, 2)
      } catch {
        return str
      }
    },
  },
}
</script>

<style scoped>
.history-container {
  max-width: 900px;
  margin: 30px auto;
  padding: 0 20px;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  flex-wrap: wrap;
  gap: 10px;
}
.page-header h2 { margin: 0; }
.toolbar {
  display: flex;
  gap: 8px;
  align-items: center;
  flex-wrap: wrap;
}
.search-input {
  padding: 7px 12px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 14px;
  width: 220px;
}
.btn-search, .btn-reset {
  padding: 7px 14px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
}
.btn-search { background: #4caf50; color: white; }
.btn-reset  { background: #9e9e9e; color: white; }
.btn-danger { padding: 7px 14px; background: #f44336; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 14px; }
.tip { text-align: center; color: #999; margin: 60px 0; }
.history-card {
  background: #fff;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  padding: 16px;
  margin-bottom: 16px;
}
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}
.card-time { font-size: 13px; color: #888; }
.btn-delete { background: none; border: none; color: #f44336; cursor: pointer; font-size: 13px; }
.card-section { margin-bottom: 8px; }
.label { font-size: 12px; color: #999; margin-bottom: 4px; }
.preview {
  background: #f5f5f5;
  border-radius: 4px;
  padding: 8px;
  font-size: 12px;
  white-space: pre-wrap;
  word-break: break-all;
  margin: 0;
  max-height: 80px;
  overflow: hidden;
}
.preview.result { border-left: 3px solid #4caf50; }
.btn-detail {
  margin-top: 8px;
  background: none;
  border: 1px solid #4caf50;
  color: #4caf50;
  padding: 5px 12px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 13px;
}
.pagination {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 16px;
  margin: 24px 0;
  font-size: 14px;
  color: #555;
}
.pagination button {
  padding: 6px 14px;
  border: 1px solid #ddd;
  border-radius: 4px;
  cursor: pointer;
  background: #fff;
}
.pagination button:disabled { color: #ccc; cursor: not-allowed; }

/* 弹窗 */
.modal-mask {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.45);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 100;
}
.modal {
  background: #fff;
  border-radius: 8px;
  width: 720px;
  max-width: 95vw;
  max-height: 80vh;
  display: flex;
  flex-direction: column;
}
.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 20px;
  border-bottom: 1px solid #eee;
  font-weight: bold;
}
.modal-close { background: none; border: none; font-size: 18px; cursor: pointer; color: #999; }
.modal-body { padding: 20px; overflow-y: auto; }
.full-content {
  background: #f5f5f5;
  border-radius: 4px;
  padding: 12px;
  font-size: 13px;
  white-space: pre-wrap;
  word-break: break-all;
  margin: 0;
}
.full-content.result { border-left: 3px solid #4caf50; }
</style>
