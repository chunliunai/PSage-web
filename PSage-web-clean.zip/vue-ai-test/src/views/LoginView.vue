<template>
  <div class="auth-container">
    <div class="auth-box">
      <h2>登录</h2>
      <p class="subtitle">AI 安全分析助手</p>

      <form @submit.prevent="handleLogin">
        <div class="form-item">
          <label>用户名</label>
          <input v-model="form.username" type="text" placeholder="请输入用户名" />
        </div>
        <div class="form-item">
          <label>密码</label>
          <input v-model="form.password" type="password" placeholder="请输入密码" />
        </div>

        <div v-if="errorMsg" class="error-msg">{{ errorMsg }}</div>

        <button type="submit" :disabled="loading">
          {{ loading ? '登录中...' : '登录' }}
        </button>
      </form>

      <p class="switch-link">
        没有账号？<a @click="$router.push('/register')">立即注册</a>
      </p>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
import { setToken, setUser } from '../utils/auth'

export default {
  data() {
    return {
      form: { username: '', password: '' },
      loading: false,
      errorMsg: '',
    }
  },
  methods: {
    async handleLogin() {
      if (!this.form.username || !this.form.password) {
        this.errorMsg = '请填写用户名和密码'
        return
      }
      this.loading = true
      this.errorMsg = ''
      try {
        const res = await axios.post('/api/auth/login', this.form)
        const result = res.data
        if (result.code === 200) {
          // 把 token 和用户信息存到 localStorage
          setToken(result.data.token)
          setUser({ id: result.data.id, username: result.data.username, role: result.data.role })
          // 跳转到主页
          this.$router.push('/')
        } else {
          this.errorMsg = result.message
        }
      } catch (err) {
        this.errorMsg = err.response?.data?.message || '登录失败，请重试'
      } finally {
        this.loading = false
      }
    },
  },
}
</script>

<style scoped>
.auth-container {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f5f5;
}
.auth-box {
  background: #fff;
  padding: 40px;
  border-radius: 8px;
  width: 360px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
}
h2 {
  margin: 0 0 4px;
  font-size: 24px;
}
.subtitle {
  color: #999;
  margin: 0 0 24px;
  font-size: 13px;
}
.form-item {
  margin-bottom: 16px;
}
.form-item label {
  display: block;
  margin-bottom: 6px;
  font-size: 14px;
  color: #333;
}
.form-item input {
  width: 100%;
  padding: 10px 12px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 14px;
  box-sizing: border-box;
}
.form-item input:focus {
  outline: none;
  border-color: #4caf50;
}
.error-msg {
  color: #c62828;
  font-size: 13px;
  margin-bottom: 12px;
  padding: 8px;
  background: #ffebee;
  border-radius: 4px;
}
button {
  width: 100%;
  padding: 12px;
  background: #4caf50;
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 15px;
  cursor: pointer;
  margin-top: 4px;
}
button:disabled {
  background: #ccc;
  cursor: not-allowed;
}
.switch-link {
  text-align: center;
  margin-top: 16px;
  font-size: 13px;
  color: #666;
}
.switch-link a {
  color: #4caf50;
  cursor: pointer;
}
</style>
