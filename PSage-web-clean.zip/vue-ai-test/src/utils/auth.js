/**
 * auth.js - Token 存取工具
 *
 * 统一管理 localStorage 里的 token 和用户信息，
 * 不要在其他地方直接操作 localStorage，都通过这里。
 */

const TOKEN_KEY = 'token'
const USER_KEY = 'user'

/** 保存 token */
export function setToken(token) {
  localStorage.setItem(TOKEN_KEY, token)
}

/** 获取 token */
export function getToken() {
  return localStorage.getItem(TOKEN_KEY)
}

/** 删除 token（退出登录时用） */
export function removeToken() {
  localStorage.removeItem(TOKEN_KEY)
}

/** 保存用户信息 */
export function setUser(user) {
  localStorage.setItem(USER_KEY, JSON.stringify(user))
}

/** 获取用户信息 */
export function getUser() {
  const str = localStorage.getItem(USER_KEY)
  return str ? JSON.parse(str) : null
}

/** 删除用户信息 */
export function removeUser() {
  localStorage.removeItem(USER_KEY)
}

/** 判断是否已登录 */
export function isLoggedIn() {
  return !!getToken()
}

/** 退出登录（清除所有本地信息） */
export function logout() {
  removeToken()
  removeUser()
}
