/**
 * request.js - axios 封装
 *
 * 作用：创建一个带有默认配置的 axios 实例。
 * 核心功能：
 *   1. 请求拦截器 - 每次发请求前自动把 token 加到请求头
 *   2. 响应拦截器 - 统一处理 401（token 过期/未登录）
 */

import axios from 'axios'
import { getToken, logout } from './auth'
import router from '../router'

// 创建 axios 实例，设置基础 URL 和超时时间
const request = axios.create({
  baseURL: '/api',   // 所有请求自动加上 /api 前缀
  timeout: 120000,   // 超时时间 120 秒（AI 并行分析耗时较长）
})

// ===== 请求拦截器 =====
// 每次发请求之前都会先经过这里
request.interceptors.request.use(
  (config) => {
    const token = getToken()
    if (token) {
      // 把 token 加到请求头，后端的 JwtInterceptor 会读取这个字段
      config.headers['Authorization'] = `Bearer ${token}`
    }
    return config
  },
  (error) => Promise.reject(error)
)

// ===== 响应拦截器 =====
// 每次收到响应之后都会先经过这里
request.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // token 过期或未登录，清除本地信息并跳转到登录页
      logout()
      router.push('/login')
    }
    return Promise.reject(error)
  }
)

export default request
