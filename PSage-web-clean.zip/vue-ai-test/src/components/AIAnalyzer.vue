<template>
  <div class="ai-analyzer">
    <h1>🔒 AI 安全分析助手</h1>

    <!-- Tab 切换 -->
    <div class="tab-bar">
      <button
        :class="['tab-btn', { active: currentTab === 'vuln' }]"
        @click="currentTab = 'vuln'"
      >漏洞分析</button>
      <button
        :class="['tab-btn', { active: currentTab === 'param' }]"
        @click="currentTab = 'param'"
      >参数分析</button>
    </div>

    <!-- ========== 漏洞分析 Tab ========== -->
    <div v-if="currentTab === 'vuln'">
      <p class="tab-desc">粘贴 HTTP 请求数据包，AI 将分析潜在漏洞</p>
      <textarea
        v-model="requestInput"
        placeholder="例如：GET /login?id=1 HTTP/1.1"
      ></textarea>
      <button class="action-btn" @click="analyzeVuln" :disabled="vulnLoading">开始分析</button>

      <div v-if="vulnLoading" class="loading">分析中...</div>
      <div v-else-if="vulnError" class="error">错误：{{ vulnError }}</div>
      <div v-else-if="vulnData" class="result">
        <div class="header">
          <h2>请求类型：{{ vulnData.requestType }} <span class="auth-tag">{{ vulnData.authRequired ? '需认证' : '无需认证' }}</span></h2>
          <span :class="'risk-badge risk-' + riskLevelClass(vulnData.overallRisk)">
            {{ vulnData.overallRisk }}
          </span>
        </div>
        <div v-for="(vul, index) in vulnData.vulnerabilities" :key="index" class="vul-card">
          <div class="vul-header">
            <h3>{{ vul.type }}</h3>
            <span :class="'risk-badge risk-' + riskLevelClass(vul.severity)">{{ vul.severity }}</span>
          </div>
          <p>{{ vul.description }}</p>
          <div v-if="vul.evidence" class="evidence">
            <strong>判断依据：</strong>{{ vul.evidence }}
          </div>
          <div v-if="vul.ratingBasis" class="rating-basis">
            <strong>评级理由：</strong>{{ vul.ratingBasis }}
          </div>
          <div class="payloads">
            <strong>测试 payload：</strong>
            <ul>
              <li v-for="(payload, i) in vul.payloads" :key="i">{{ payload }}</li>
            </ul>
          </div>
          <div v-if="vul.mitigation" class="mitigation">
            <strong>修复建议：</strong>{{ vul.mitigation }}
          </div>
        </div>
        <p class="summary"><strong>总结：</strong>{{ vulnData.summary }}</p>
      </div>
      <div v-else class="no-data">暂无数据</div>
    </div>

    <!-- ========== 参数分析 Tab ========== -->
    <div v-if="currentTab === 'param'">
      <p class="tab-desc">粘贴请求包和/或返回包，AI 将分析参数含义和风险</p>

      <div class="param-input-group">
        <label>请求包（选填）</label>
        <textarea
          v-model="paramRequestInput"
          placeholder="例如：POST /api/order/create HTTP/1.1&#10;Host: shop.example.com&#10;Content-Type: application/json&#10;&#10;{&quot;skuId&quot;: 88752, &quot;amount&quot;: 199.00}"
        ></textarea>
      </div>

      <div class="param-input-group">
        <label>返回包（选填）</label>
        <textarea
          v-model="paramResponseInput"
          placeholder="例如：HTTP/1.1 200 OK&#10;Content-Type: application/json&#10;&#10;{&quot;code&quot;: 0, &quot;data&quot;: {&quot;orderId&quot;: 10086}}"
        ></textarea>
      </div>

      <button class="action-btn" @click="analyzeParam" :disabled="paramLoading">开始分析</button>

      <div v-if="paramLoading" class="loading">分析中...</div>
      <div v-else-if="paramError" class="error">错误：{{ paramError }}</div>
      <div v-else-if="paramData" class="result">

        <!-- 请求包参数分析结果 -->
        <div v-if="paramData.requestParams && paramData.requestParams.length > 0" class="param-section">
          <h2>请求包参数</h2>
          <table class="param-table">
            <thead>
              <tr>
                <th>参数名</th>
                <th>值</th>
                <th>翻译</th>
                <th>业务含义</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(p, i) in paramData.requestParams" :key="'req-' + i">
                <td class="param-name">{{ p.name }}</td>
                <td class="param-value">{{ p.value }}</td>
                <td>{{ p.translation }}</td>
                <td>{{ p.businessRole }}</td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- 返回包参数分析结果 -->
        <div v-if="paramData.responseParams && paramData.responseParams.length > 0" class="param-section">
          <h2>返回包参数</h2>
          <table class="param-table">
            <thead>
              <tr>
                <th>字段名</th>
                <th>值</th>
                <th>翻译</th>
                <th>业务含义</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(p, i) in paramData.responseParams" :key="'res-' + i">
                <td class="param-name">{{ p.name }}</td>
                <td class="param-value">{{ p.value }}</td>
                <td>{{ p.translation }}</td>
                <td>{{ p.businessRole }}</td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- 报错分析结果 -->
        <div v-if="paramData.errorAnalysis && paramData.errorAnalysis.hasError" class="param-section">
          <h2>报错信息分析</h2>
          <div class="error-analysis-card">
            <div class="error-card-header">
              <div class="error-type-badge">{{ paramData.errorAnalysis.errorType }}</div>
              <div class="error-summary">{{ paramData.errorAnalysis.summary }}</div>
            </div>
            <div class="error-detail">
              <div class="error-block">
                <div class="error-block-title">详细分析</div>
                <div class="error-block-content">{{ paramData.errorAnalysis.explanation }}</div>
              </div>
              <div class="error-block">
                <div class="error-block-title">可能原因</div>
                <div class="error-block-content">{{ paramData.errorAnalysis.possibleCause }}</div>
              </div>
              <div class="error-block">
                <div class="error-block-title">信息泄露风险</div>
                <div class="error-block-content security-exposure">{{ paramData.errorAnalysis.securityExposure }}</div>
              </div>
            </div>
          </div>
        </div>

        <!-- 无报错提示 -->
        <div v-if="paramData.errorAnalysis && !paramData.errorAnalysis.hasError && paramResponseInput.trim()" class="param-section">
          <h2>报错信息分析</h2>
          <div class="no-error-hint">返回包未发现错误信息</div>
        </div>

      </div>
      <div v-else-if="!paramLoading && !paramError" class="no-data">暂无数据</div>
    </div>

  </div>
</template>

<script>
import request from '../utils/request';

export default {
  data() {
    return {
      currentTab: 'vuln',

      // 漏洞分析
      requestInput: '',
      vulnLoading: false,
      vulnError: '',
      vulnData: null,

      // 参数分析
      paramRequestInput: '',
      paramResponseInput: '',
      paramLoading: false,
      paramError: '',
      paramData: null,
    };
  },
  methods: {
    riskLevelClass(level) {
      if (level === '严重') return 'critical';
      if (level === '高危') return 'high';
      if (level === '中危') return 'medium';
      if (level === '低危') return 'low';
      if (level === '信息') return 'info';
      if (level === '安全') return 'safe';
      return '';
    },

    // 漏洞分析
    async analyzeVuln() {
      if (!this.requestInput.trim()) {
        alert('请输入请求数据包');
        return;
      }
      this.vulnLoading = true;
      this.vulnError = '';
      this.vulnData = null;
      try {
        const response = await request.post('/ai/chat', {
          userInput: this.requestInput,
        });
        const result = response.data;
        if (result.code === 200) {
          this.vulnData = JSON.parse(result.message);
        } else {
          this.vulnError = result.message;
        }
      } catch (err) {
        this.vulnError = err.message;
      } finally {
        this.vulnLoading = false;
      }
    },

    // 参数分析
    async analyzeParam() {
      if (!this.paramRequestInput.trim() && !this.paramResponseInput.trim()) {
        alert('请求包和返回包至少填写一个');
        return;
      }
      this.paramLoading = true;
      this.paramError = '';
      this.paramData = null;
      try {
        const body = {};
        if (this.paramRequestInput.trim()) body.requestRaw = this.paramRequestInput;
        if (this.paramResponseInput.trim()) body.responseRaw = this.paramResponseInput;

        const response = await request.post('/ai/param-analyze', body);
        const result = response.data;
        if (result.code === 200) {
          this.paramData = JSON.parse(result.message);
        } else {
          this.paramError = result.message;
        }
      } catch (err) {
        this.paramError = err.message;
      } finally {
        this.paramLoading = false;
      }
    },
  },
};
</script>

<style scoped>
.ai-analyzer {
  max-width: 900px;
  margin: 50px auto;
  padding: 0 20px;
  font-family: Arial, sans-serif;
}

/* Tab 栏 */
.tab-bar {
  display: flex;
  gap: 0;
  margin: 20px 0 15px 0;
  border-bottom: 2px solid #e0e0e0;
}
.tab-btn {
  padding: 10px 24px;
  border: none;
  background: none;
  cursor: pointer;
  font-size: 15px;
  color: #666;
  border-bottom: 2px solid transparent;
  margin-bottom: -2px;
  transition: all 0.2s;
}
.tab-btn:hover {
  color: #333;
}
.tab-btn.active {
  color: #1976d2;
  border-bottom-color: #1976d2;
  font-weight: bold;
}
.tab-desc {
  color: #888;
  font-size: 14px;
  margin-bottom: 15px;
}

/* 输入区域 */
textarea {
  width: 100%;
  height: 150px;
  font-family: monospace;
  margin-bottom: 10px;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 4px;
  resize: vertical;
  box-sizing: border-box;
}
.param-input-group {
  margin-bottom: 12px;
}
.param-input-group label {
  display: block;
  font-weight: bold;
  margin-bottom: 5px;
  color: #333;
  font-size: 14px;
}
.param-input-group textarea {
  height: 120px;
}

/* 按钮 */
.action-btn {
  padding: 8px 20px;
  background-color: #4caf50;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
}
.action-btn:disabled {
  background-color: #ccc;
  cursor: not-allowed;
}

/* 状态提示 */
.loading, .error, .no-data {
  margin-top: 20px;
  padding: 10px;
  border-radius: 4px;
}
.loading { background: #e3f2fd; }
.error { background: #ffebee; color: #c62828; }

/* 漏洞分析结果 */
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin: 20px 0;
}
.risk-badge {
  padding: 3px 10px;
  border-radius: 12px;
  font-size: 13px;
  font-weight: bold;
}
.risk-critical { background: #b71c1c; color: #fff; }
.risk-high     { background: #ffebee; color: #d32f2f; }
.risk-medium   { background: #fff3e0; color: #e65100; }
.risk-low      { background: #e8f5e9; color: #388e3c; }
.risk-info     { background: #e3f2fd; color: #1565c0; }
.risk-safe     { background: #e8f5e9; color: #388e3c; }
.auth-tag {
  font-size: 12px;
  font-weight: normal;
  color: #888;
  margin-left: 8px;
}
.vul-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}
.vul-header h3 { margin: 0; }
.evidence {
  background: #f3f3f3;
  padding: 8px 10px;
  border-radius: 4px;
  margin: 8px 0;
  font-size: 13px;
}
.rating-basis {
  background: #fff8e1;
  padding: 8px 10px;
  border-radius: 4px;
  margin: 8px 0;
  font-size: 13px;
}
.mitigation {
  background: #e8f5e9;
  padding: 8px 10px;
  border-radius: 4px;
  margin-top: 8px;
  font-size: 13px;
}
.vul-card {
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 15px;
  margin: 15px 0;
  background: #fafafa;
}
.payloads {
  background: #fff;
  padding: 10px;
  border-radius: 4px;
  border-left: 3px solid #ff9800;
}
.summary {
  margin-top: 20px;
  font-size: 1.1em;
}

/* 参数分析结果 */
.param-section {
  margin-top: 25px;
}
.param-section h2 {
  font-size: 18px;
  margin-bottom: 12px;
  padding-bottom: 6px;
  border-bottom: 1px solid #e0e0e0;
}
.param-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
}
.param-table th {
  background: #f5f5f5;
  padding: 8px 10px;
  text-align: left;
  border: 1px solid #e0e0e0;
  font-weight: bold;
  white-space: nowrap;
}
.param-table td {
  padding: 8px 10px;
  border: 1px solid #e0e0e0;
  vertical-align: top;
}
.param-table tr:hover {
  background: #fafafa;
}
.param-name {
  font-family: monospace;
  font-weight: bold;
  color: #1565c0;
  white-space: nowrap;
}
.param-value {
  font-family: monospace;
  color: #555;
  max-width: 200px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* 报错分析 */
.error-analysis-card {
  border: 1px solid #ffcdd2;
  border-radius: 8px;
  padding: 18px;
  background: #fff5f5;
}
.error-card-header {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 15px;
  padding-bottom: 12px;
  border-bottom: 1px solid #ffcdd2;
}
.error-type-badge {
  display: inline-block;
  background: #d32f2f;
  color: #fff;
  padding: 3px 12px;
  border-radius: 12px;
  font-size: 13px;
  font-weight: bold;
  flex-shrink: 0;
}
.error-summary {
  font-size: 15px;
  font-weight: bold;
  color: #333;
}
.error-detail {
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.error-block {
  background: #fff;
  border-radius: 6px;
  padding: 12px;
  border-left: 3px solid #ef9a9a;
}
.error-block-title {
  font-size: 13px;
  font-weight: bold;
  color: #c62828;
  margin-bottom: 6px;
}
.error-block-content {
  font-size: 14px;
  line-height: 1.8;
  color: #444;
}
.security-exposure {
  color: #e65100;
}
.no-error-hint {
  padding: 10px;
  background: #e8f5e9;
  border-radius: 4px;
  color: #388e3c;
}
</style>
